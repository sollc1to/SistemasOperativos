#ifndef MUTEX_H 
#define MUTEX_H 

void mutex_init(); 
void mutex_lock(); 
void mutex_unlock(); 

#endif
