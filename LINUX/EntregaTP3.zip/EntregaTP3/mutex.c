#include <xinu.h>
sid32 semaforo; 



void mutex_init(void){ //En caso de que la creación de error, el mismo crear del semáforo devuelve error.

semaforo = semcreate(1);



}


void mutex_lock(void){

wait(semaforo);

}



void mutex_unlock(void){

signal(semaforo);

}
